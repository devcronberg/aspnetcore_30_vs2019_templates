﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AspNetCore30_vs2019_templates.Models
{
    // You can delete this file - just a marker
    public class Marker
    {
    }
}
